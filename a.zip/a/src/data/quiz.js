export const quizQuestions = [
    {
        id: 1,
        question: "What does the 'crossed-out wheeled bin' symbol on electronics mean?",
        options: ["It is trash", "Do not throw in regular trash", "It is broken", "Recycle only on Tuesdays"],
        correct: 1 // index
    },
    {
        id: 2,
        question: "Which precious metal is commonly found in computer circuit boards?",
        options: ["Silver", "Gold", "Platinum", "All of the above"],
        correct: 3
    },
    {
        id: 3,
        question: "What toxic substance is often found in old CRT monitors?",
        options: ["Lead", "Mercury", "Arsenic", "Cadmium"],
        correct: 0
    },
    {
        id: 4,
        question: "Which component in a smartphone contains the most Rare Earth Elements?",
        options: ["Screen", "Battery", "Speakers/Vibration Motor", "Plastic Case"],
        correct: 2
    },
    {
        id: 5,
        question: "What percentage of e-waste is formally recycled globally?",
        options: ["Less than 20%", "About 50%", "Over 75%", "Nearly 10%"],
        correct: 0
    },
    {
        id: 6,
        question: "Recycling one million laptops saves enough energy to power how many homes for a year?",
        options: ["50", "500", "3,500", "10,000"],
        correct: 2
    },
    {
        id: 7,
        question: "Which of these is NOT a benefit of recycling e-waste?",
        options: ["Conserving natural resources", "Reducing greenhouse gas emissions", "Creating jobs", "Increasing landfill size"],
        correct: 3
    },
    {
        id: 8,
        question: "What is 'planned obsolescence'?",
        options: ["Designing products to fail after a certain time", "Planning to recycle", "Old technology", "Software updates"],
        correct: 0
    },
    {
        id: 9,
        question: "Which battery type is most common in modern smartphones?",
        options: ["Nickel-Cadmium", "Lead-Acid", "Lithium-Ion", "Alkaline"],
        correct: 2
    },
    {
        id: 10,
        question: "What should you do before recycling a computer or phone?",
        options: ["Wash it with water", "Wipe personal data", "Take it apart yourself", "Paint it green"],
        correct: 1
    }
];
