export const electronicItems = [
    {
        id: 1,
        name: "Smartphone",
        category: "Mobile",
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=500&auto=format&fit=crop",
        breakdown: [
            { name: "Plastics", percentage: 40, color: "#3b82f6" },
            { name: "Metals (Copper, Aluminum)", percentage: 40, color: "#eab308" },
            { name: "Glass/Ceramics", percentage: 20, color: "#ef4444" }
        ],
        rareEarths: ["Gold (Circuits)", "Neodymium (Speakers)", "Indium (Screen)", "Lithium (Battery)"],
        impact: "One smartphone battery can pollute 60,000 liters of water if leaked."
    },
    {
        id: 2,
        name: "Laptop",
        category: "Computing",
        image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=500&auto=format&fit=crop",
        breakdown: [
            { name: "Metals (Steel, Alum.)", percentage: 50, color: "#9ca3af" },
            { name: "Plastics", percentage: 30, color: "#3b82f6" },
            { name: "Glass", percentage: 10, color: "#ef4444" },
            { name: "Battery/Circuitry", percentage: 10, color: "#10b981" }
        ],
        rareEarths: ["Gold", "Palladium", "Silver", "Cobalt"],
        impact: "Recycling 1 million laptops saves the energy equivalent to the electricity used by 3,500 US homes in a year."
    },
    {
        id: 3,
        name: "AA Battery",
        category: "Power",
        image: "https://images.unsplash.com/photo-1619623696882-8959877b102b?q=80&w=500&auto=format&fit=crop",
        breakdown: [
            { name: "Zinc/Manganese", percentage: 60, color: "#78716c" },
            { name: "Steel", percentage: 25, color: "#9ca3af" },
            { name: "Paper/Plastic", percentage: 15, color: "#3b82f6" }
        ],
        rareEarths: ["Zinc", "Manganese"],
        impact: "Batteries contain toxic heavy metals like lead and cadmium which can dissolve into the soil."
    },
    {
        id: 4,
        name: "Microwave Oven",
        category: "Appliance",
        image: "https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?q=80&w=500&auto=format&fit=crop",
        breakdown: [
            { name: "Steel", percentage: 50, color: "#9ca3af" },
            { name: "Glass", percentage: 15, color: "#ef4444" },
            { name: "Copper", percentage: 10, color: "#eab308" },
            { name: "Plastics", percentage: 25, color: "#3b82f6" }
        ],
        rareEarths: ["Copper", "Magnetite"],
        impact: "The magnetron contains beryllium oxide, which can be toxic if broken and inhaled."
    },
    {
        id: 5,
        name: "LED Light Bulb",
        category: "Lighting",
        image: "https://images.unsplash.com/photo-1550989460-0adf9ea622e2?q=80&w=500&auto=format&fit=crop",
        breakdown: [
            { name: "Aluminum", percentage: 40, color: "#9ca3af" },
            { name: "Plastic", percentage: 40, color: "#3b82f6" },
            { name: "Circuit Board", percentage: 20, color: "#10b981" }
        ],
        rareEarths: ["Indium", "Gallium", "Cerium"],
        impact: "LEDs use rare earth elements crucial for modern tech, making recycling essential despite their long life."
    }
];
