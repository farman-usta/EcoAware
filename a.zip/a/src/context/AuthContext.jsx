import React, { createContext, useState, useEffect, useContext } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check local storage for existing session
    const storedUser = localStorage.getItem('wasteHubUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = (email, password) => {
    // Simulate API call
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (email && password) {
          const fakeUser = {
            id: 'u_' + Date.now(),
            name: email.split('@')[0],
            email,
            score: parseInt(localStorage.getItem('wasteHubScore')) || 0
          };
          setUser(fakeUser);
          localStorage.setItem('wasteHubUser', JSON.stringify(fakeUser));
          resolve(fakeUser);
        } else {
          reject(new Error("Invalid credentials"));
        }
      }, 800);
    });
  };

  const signup = (name, email, password) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const fakeUser = {
          id: 'u_' + Date.now(),
          name,
          email,
          score: 0
        };
        setUser(fakeUser);
        localStorage.setItem('wasteHubUser', JSON.stringify(fakeUser));
        localStorage.setItem('wasteHubScore', '0');
        resolve(fakeUser);
      }, 800);
    });
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('wasteHubUser');
  };

  const updateScore = (points) => {
    if (user) {
      const newScore = (user.score || 0) + points;
      const updatedUser = { ...user, score: newScore };
      setUser(updatedUser);
      localStorage.setItem('wasteHubUser', JSON.stringify(updatedUser));
      localStorage.setItem('wasteHubScore', newScore.toString());
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, loading, updateScore }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
