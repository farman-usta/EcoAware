import React from 'react';
import { Link } from 'react-router-dom';
import { Search, Scan, Award, ArrowRight } from 'lucide-react';

const FeatureCard = ({ icon: Icon, title, description, to, colorClass }) => (
    <Link
        to={to}
        className="glass-panel p-6 flex flex-col items-start gap-4 hover:bg-slate-800/50 transition-all hover:scale-[1.02] group"
    >
        <div className={`p-3 rounded-xl ${colorClass} bg-opacity-20`}>
            <Icon size={32} className={colorClass.replace('bg-', 'text-')} />
        </div>
        <div>
            <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">{title}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">{description}</p>
        </div>
        <div className="mt-auto flex items-center gap-2 text-primary font-medium text-sm">
            Try it now <ArrowRight size={16} />
        </div>
    </Link>
);

const Home = () => {
    return (
        <div className="flex flex-col gap-16 py-8">
            {/* Hero Section */}
            <section className="text-center py-12 px-4 relative overflow-hidden">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[100px] -z-10"></div>

                <span className="inline-block py-1 px-3 rounded-full bg-primary/10 text-primary text-xs font-bold tracking-wider mb-6 border border-primary/20">
                    SUSTAINABILITY REIMAGINED
                </span>
                <h1 className="text-5xl md:text-7xl font-extrabold mb-6 tracking-tight">
                    Turn Trash into <br />
                    <span className="text-gradient">Treasure</span>
                </h1>
                <p className="max-w-2xl mx-auto text-lg text-gray-400 mb-10 leading-relaxed">
                    Most electronics hold secret value. Don't throw away gold, copper, and rare earth metals.
                    Discover what's inside your old gadgets and how to recycle them properly.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                    <Link to="/scanner" className="glass-button text-lg px-8 py-4 shadow-xl shadow-primary/20">
                        <Scan className="mr-2" /> Scan an Item
                    </Link>
                    <Link to="/quiz" className="px-8 py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-colors flex items-center justify-center gap-2">
                        <Award size={20} /> Take the Quiz
                    </Link>
                </div>
            </section>

            {/* Features Grid */}
            <section className="grid md:grid-cols-3 gap-6">
                <FeatureCard
                    to="/deconstructor"
                    icon={Search}
                    title="Material Deconstructor"
                    description="Search for any device to see its chemical makeup. Find out how much gold is in your old phone."
                    colorClass="bg-blue-500 text-blue-500"
                />
                <FeatureCard
                    to="/scanner"
                    icon={Scan}
                    title="Smart Component Scanner"
                    description="Use AI to identify e-waste components via camera and get instant recycling values."
                    colorClass="bg-emerald-500 text-emerald-500"
                />
                <FeatureCard
                    to="/quiz"
                    icon={Award}
                    title="Urban Miner Quiz"
                    description="Test your knowledge on toxic components and recycling symbols. Earn points and level up."
                    colorClass="bg-violet-500 text-violet-500"
                />
            </section>

            {/* Stats/Info Section */}
            <section className="glass-panel p-8 md:p-12 text-center">
                <h2 className="text-3xl font-bold mb-8">Why it Matters?</h2>
                <div className="grid md:grid-cols-3 gap-8">
                    <div>
                        <div className="text-4xl font-bold text-primary mb-2">53.6 Mt</div>
                        <div className="text-gray-400 text-sm">E-waste generated annually worldwide</div>
                    </div>
                    <div>
                        <div className="text-4xl font-bold text-blue-500 mb-2">$57 Billion</div>
                        <div className="text-gray-400 text-sm">Value of raw materials in e-waste</div>
                    </div>
                    <div>
                        <div className="text-4xl font-bold text-violet-500 mb-2">17.4%</div>
                        <div className="text-gray-400 text-sm">Only this much is properly collected</div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Home;
