import React, { useState, useRef } from 'react';
import { Upload, Scan, CheckCircle, AlertTriangle, X } from 'lucide-react';
import { electronicItems } from '../data/items';

const Scanner = () => {
    const [file, setFile] = useState(null);
    const [scanning, setScanning] = useState(false);
    const [result, setResult] = useState(null);
    const fileInputRef = useRef(null);

    const handleFileChange = (e) => {
        const selected = e.target.files[0];
        if (selected) {
            setFile(URL.createObjectURL(selected));
            setResult(null);
            startScan();
        }
    };

    const startScan = () => {
        setScanning(true);
        // Simulate AI Processing
        setTimeout(() => {
            setScanning(false);
            // Pick a random item for demo
            const randomItem = electronicItems[Math.floor(Math.random() * electronicItems.length)];
            setResult(randomItem);
        }, 2500);
    };

    const resetScanner = () => {
        setFile(null);
        setResult(null);
        if (fileInputRef.current) fileInputRef.current.value = null;
    };

    return (
        <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl font-bold mb-4">Smart Component Scanner</h1>
            <p className="text-gray-400 mb-10">
                Upload a photo of your e-waste. Our AI identifies the components and materials.
            </p>

            {!file ? (
                <div
                    className="border-2 border-dashed border-gray-600 rounded-3xl p-12 bg-slate-800/30 hover:bg-slate-800/50 hover:border-primary transition-all cursor-pointer group"
                    onClick={() => fileInputRef.current.click()}
                >
                    <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                        <Upload className="text-primary" size={40} />
                    </div>
                    <h3 className="text-xl font-bold mb-2">Upload or Drop Image</h3>
                    <p className="text-gray-500 text-sm">Supports JPG, PNG (Max 5MB)</p>
                    <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept="image/*"
                        onChange={handleFileChange}
                    />
                </div>
            ) : (
                <div className="relative glass-panel p-6 overflow-hidden min-h-[400px] flex flex-col items-center justify-center">
                    <button
                        onClick={resetScanner}
                        className="absolute top-4 right-4 p-2 rounded-full bg-black/50 hover:bg-black/70 z-20"
                    >
                        <X size={20} />
                    </button>

                    <div className="relative w-64 h-64 mb-6 rounded-xl overflow-hidden shadow-2xl">
                        <img src={file} alt="Scan Target" className="w-full h-full object-cover" />

                        {/* Scanning Overlay Animation */}
                        {scanning && (
                            <div className="absolute inset-0 bg-primary/20 z-10 animate-pulse">
                                <div className="absolute top-0 left-0 w-full h-1 bg-primary shadow-[0_0_15px_rgba(16,185,129,1)] animate-[scan_2s_ease-in-out_infinite]"></div>
                            </div>
                        )}

                        <style>{`
              @keyframes scan {
                0% { top: 0; }
                50% { top: 100%; }
                100% { top: 0; }
              }
            `}</style>
                    </div>

                    {scanning ? (
                        <div className="text-center">
                            <div className="flex items-center justify-center gap-2 text-primary font-bold text-xl mb-2">
                                <Scan className="animate-spin" /> Analyzing Component...
                            </div>
                            <p className="text-gray-400 text-sm">Identifying materials and recyclability</p>
                        </div>
                    ) : result ? (
                        <div className="w-full max-w-lg animate-fade-in text-left bg-slate-800/50 rounded-xl p-6 border border-white/5">
                            <div className="flex items-center gap-4 mb-4 border-b border-white/5 pb-4">
                                <div className="bg-green-500/20 p-3 rounded-full text-green-500">
                                    <CheckCircle size={28} />
                                </div>
                                <div>
                                    <div className="text-sm text-gray-400">Identified Item</div>
                                    <h2 className="text-2xl font-bold">{result.name}</h2>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4 mb-6">
                                <div className="bg-slate-900/50 p-3 rounded-lg">
                                    <div className="text-gray-400 text-xs mb-1">Valuable Metals</div>
                                    <div className="text-yellow-400 font-semibold text-sm">
                                        {result.rareEarths.slice(0, 2).join(', ')}
                                    </div>
                                </div>
                                <div className="bg-slate-900/50 p-3 rounded-lg">
                                    <div className="text-gray-400 text-xs mb-1">Sustainability Score</div>
                                    <div className="text-primary font-semibold text-sm">High (Recoverable)</div>
                                </div>
                            </div>

                            <div className="mt-4 pt-4 border-t border-white/5 text-center">
                                <p className="text-sm text-gray-300 mb-3">Don't trash it! This item contains valuable materials.</p>
                                <button className="glass-button w-full justify-center">
                                    Find Nearest Recycling Center
                                </button>
                            </div>
                        </div>
                    ) : null}
                </div>
            )}
        </div>
    );
};

export default Scanner;
