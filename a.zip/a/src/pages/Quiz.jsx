import React, { useState } from 'react';
import { quizQuestions } from '../data/quiz';
import { useAuth } from '../context/AuthContext';
import { Check, X, Trophy, RefreshCcw, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Quiz = () => {
    const { user, updateScore } = useAuth();
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [selectedOption, setSelectedOption] = useState(null);
    const [score, setScore] = useState(0);
    const [showResult, setShowResult] = useState(false);
    const [isAnswered, setIsAnswered] = useState(false);

    const handleOptionClick = (index) => {
        if (isAnswered) return;
        setSelectedOption(index);
        setIsAnswered(true);

        if (index === quizQuestions[currentQuestion].correct) {
            setScore(s => s + 1);
        }
    };

    const nextQuestion = () => {
        if (currentQuestion < quizQuestions.length - 1) {
            setCurrentQuestion(c => c + 1);
            setSelectedOption(null);
            setIsAnswered(false);
        } else {
            finishQuiz();
        }
    };

    const finishQuiz = () => {
        setShowResult(true);
        if (user) {
            updateScore(score * 10); // 10 points per question
        }
    };

    const resetQuiz = () => {
        setCurrentQuestion(0);
        setSelectedOption(null);
        setScore(0);
        setShowResult(false);
        setIsAnswered(false);
    };

    if (showResult) {
        return (
            <div className="max-w-2xl mx-auto text-center py-10 animate-fade-in">
                <div className="glass-panel p-10 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"></div>

                    <div className="w-24 h-24 bg-yellow-400/20 rounded-full flex items-center justify-center mx-auto mb-6 text-yellow-400">
                        <Trophy size={48} />
                    </div>

                    <h2 className="text-3xl font-bold mb-2">Quiz Completed!</h2>
                    <p className="text-gray-400 mb-8">You are becoming a true Urban Miner.</p>

                    <div className="text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-500 mb-4">
                        {score} / {quizQuestions.length}
                    </div>

                    <p className="text-lg mb-8">
                        {score === quizQuestions.length ? "Perfect Score! You're an expert." :
                            score > 5 ? "Great job! You know your stuff." : "Keep learning! Check out the Deconstructor."}
                    </p>

                    {!user && (
                        <div className="bg-blue-500/10 border border-blue-500/30 p-4 rounded-lg mb-8 text-sm">
                            <Link to="/login" className="text-primary font-bold hover:underline">Log in</Link> to save your score and compete on the leaderboard!
                        </div>
                    )}

                    <button onClick={resetQuiz} className="glass-button px-8">
                        <RefreshCcw size={18} className="mr-2" /> Try Again
                    </button>
                </div>
            </div>
        );
    }

    const question = quizQuestions[currentQuestion];

    return (
        <div className="max-w-3xl mx-auto py-8">
            <div className="flex justify-between items-center mb-6 text-sm font-medium text-gray-400">
                <span>Question {currentQuestion + 1} of {quizQuestions.length}</span>
                <span>Score: {score}</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-800 h-2 rounded-full mb-8 overflow-hidden">
                <div
                    className="bg-primary h-full transition-all duration-500 ease-out"
                    style={{ width: `${((currentQuestion + 1) / quizQuestions.length) * 100}%` }}
                ></div>
            </div>

            <div className="glass-panel p-8 min-h-[400px] flex flex-col">
                <h2 className="text-2xl font-bold mb-8 leading-relaxed">{question.question}</h2>

                <div className="space-y-3 flex-grow">
                    {question.options.map((option, index) => {
                        let optionClass = "w-full p-4 rounded-xl text-left transition-all border border-transparent flex items-center justify-between group ";

                        if (isAnswered) {
                            if (index === question.correct) {
                                optionClass += "bg-green-500/20 border-green-500 text-green-400";
                            } else if (index === selectedOption) {
                                optionClass += "bg-red-500/20 border-red-500 text-red-400";
                            } else {
                                optionClass += "bg-slate-800/30 text-gray-500 opacity-50";
                            }
                        } else {
                            optionClass += "bg-slate-800/50 hover:bg-slate-700 hover:border-primary/50 hover:pl-6";
                        }

                        return (
                            <button
                                key={index}
                                onClick={() => handleOptionClick(index)}
                                disabled={isAnswered}
                                className={optionClass}
                            >
                                <span className="font-medium">{option}</span>
                                {isAnswered && index === question.correct && <Check size={20} />}
                                {isAnswered && index === selectedOption && index !== question.correct && <X size={20} />}
                            </button>
                        );
                    })}
                </div>

                {isAnswered && (
                    <div className="mt-8 flex justify-end animate-fade-in">
                        <button onClick={nextQuestion} className="glass-button px-8">
                            {currentQuestion === quizQuestions.length - 1 ? 'Finish' : 'Next Question'} <ArrowRight size={18} className="ml-2" />
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Quiz;
