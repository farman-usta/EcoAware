import React, { useState } from 'react';
import { electronicItems } from '../data/items';
import { Search, Info, X } from 'lucide-react';

const Deconstructor = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedItem, setSelectedItem] = useState(null);

    const filteredItems = electronicItems.filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="relative min-h-[80vh]">
            <div className="text-center mb-10">
                <h1 className="text-4xl font-bold mb-4">Material Deconstructor</h1>
                <p className="text-gray-400">Discover what's really inside your electronics.</p>

                <div className="max-w-xl mx-auto mt-8 relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
                    <input
                        type="text"
                        placeholder="Search for a device (e.g., Laptop, Battery)..."
                        className="glass-input pl-12 py-4 rounded-full text-lg border-primary/30 focus:border-primary"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredItems.map(item => (
                    <div
                        key={item.id}
                        onClick={() => setSelectedItem(item)}
                        className="glass-panel overflow-hidden cursor-pointer hover:border-primary/50 transition-all hover:scale-[1.02] group"
                    >
                        <div className="h-48 overflow-hidden relative">
                            <img src={item.image} alt={item.name} className="w-full h-full object-cover transition-transform group-hover:scale-110" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-4">
                                <h3 className="text-xl font-bold">{item.name}</h3>
                            </div>
                        </div>
                        <div className="p-4">
                            <div className="flex flex-wrap gap-2 mb-3">
                                {item.breakdown.slice(0, 2).map((part, idx) => (
                                    <span key={idx} className="text-xs px-2 py-1 rounded bg-slate-800 text-gray-300">
                                        {part.name}
                                    </span>
                                ))}
                                {item.breakdown.length > 2 && <span className="text-xs px-2 py-1 rounded bg-slate-800 text-gray-300">+More</span>}
                            </div>
                            <button className="text-primary text-sm font-medium flex items-center gap-1 group-hover:underline">
                                View Full Breakdown <Info size={14} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>

            {filteredItems.length === 0 && (
                <div className="text-center text-gray-500 mt-12">
                    No items found matching "{searchTerm}"
                </div>
            )}

            {/* Detail Modal Overlay */}
            {selectedItem && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={() => setSelectedItem(null)}>
                    <div className="glass-panel w-full max-w-2xl max-h-[90vh] overflow-y-auto relative p-0" onClick={e => e.stopPropagation()}>
                        <button
                            className="absolute top-4 right-4 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white z-10 transition-colors"
                            onClick={() => setSelectedItem(null)}
                        >
                            <X size={20} />
                        </button>

                        <div className="h-64 sm:h-80 relative">
                            <img src={selectedItem.image} alt={selectedItem.name} className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent"></div>
                            <div className="absolute bottom-6 left-6">
                                <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-sm font-bold mb-2 inline-block">
                                    {selectedItem.category}
                                </span>
                                <h2 className="text-4xl font-bold">{selectedItem.name}</h2>
                            </div>
                        </div>

                        <div className="p-6 sm:p-8 space-y-8">
                            {/* Material Breakdown Chart */}
                            <div>
                                <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                                    <Info className="text-primary" size={20} />
                                    Material Composition
                                </h3>
                                <div className="flex h-6 w-full rounded-full overflow-hidden mb-4">
                                    {selectedItem.breakdown.map((part, idx) => (
                                        <div
                                            key={idx}
                                            style={{ width: `${part.percentage}%`, backgroundColor: part.color }}
                                            title={`${part.name}: ${part.percentage}%`}
                                        />
                                    ))}
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    {selectedItem.breakdown.map((part, idx) => (
                                        <div key={idx} className="flex items-center gap-2 text-sm">
                                            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: part.color }}></div>
                                            <span className="text-gray-300">{part.name}</span>
                                            <span className="font-bold ml-auto">{part.percentage}%</span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* Rare Earths */}
                            <div className="bg-slate-800/50 p-6 rounded-xl border border-white/5">
                                <h3 className="text-lg font-bold mb-3 text-yellow-400">Rare Earth Elements</h3>
                                <div className="flex flex-wrap gap-2">
                                    {selectedItem.rareEarths.map((el, idx) => (
                                        <span key={idx} className="bg-yellow-400/10 text-yellow-400 px-3 py-1 rounded-lg text-sm border border-yellow-400/20">
                                            {el}
                                        </span>
                                    ))}
                                </div>
                            </div>

                            {/* Impact */}
                            <div>
                                <h3 className="text-lg font-bold mb-2">Environmental Impact</h3>
                                <p className="text-gray-400 leading-relaxed border-l-4 border-red-500 pl-4 py-1">
                                    {selectedItem.impact}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Deconstructor;
