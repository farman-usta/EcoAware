import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Menu, X, Recycle, Search, Scan, Award, LogOut, User } from 'lucide-react';

const Navbar = () => {
    const { user, logout } = useAuth();
    const [isOpen, setIsOpen] = useState(false);
    const location = useLocation();

    const isActive = (path) => location.pathname === path ? 'text-primary' : 'text-gray-300 hover:text-white';

    const NavLink = ({ to, icon: Icon, label }) => (
        <Link
            to={to}
            className={`flex items-center gap-2 font-medium transition-colors ${isActive(to)}`}
            onClick={() => setIsOpen(false)}
        >
            <Icon size={18} />
            {label}
        </Link>
    );

    return (
        <nav className="fixed top-0 left-0 right-0 z-50 glass-panel border-t-0 border-x-0 rounded-none bg-opacity-80 backdrop-blur-md">
            <div className="container mx-auto px-4 h-16 flex items-center justify-between">
                {/* Logo */}
                <Link to="/" className="flex items-center gap-2 text-xl font-bold text-white">
                    <div className="bg-gradient-to-br from-primary to-blue-500 p-2 rounded-lg">
                        <Recycle size={24} className="text-white" />
                    </div>
                    <span className="text-gradient">EcoAware</span>
                </Link>

                {/* Desktop Nav */}
                <div className="hidden md:flex items-center gap-8">
                    <NavLink to="/deconstructor" icon={Search} label="Deconstructor" />
                    <NavLink to="/scanner" icon={Scan} label="Scanner" />
                    <NavLink to="/quiz" icon={Award} label="Quiz" />
                </div>

                {/* Auth / Mobile Menu Toggle */}
                <div className="flex items-center gap-4">
                    {user ? (
                        <div className="hidden md:flex items-center gap-4">
                            <div className="flex items-center gap-2 text-sm text-gray-300">
                                <User size={16} />
                                <span>{user.name}</span>
                                <span className="bg-primary/20 text-primary px-2 py-0.5 rounded-full text-xs">
                                    {user.score} pts
                                </span>
                            </div>
                            <button
                                onClick={logout}
                                className="text-gray-400 hover:text-white transition-colors"
                                title="Logout"
                            >
                                <LogOut size={20} />
                            </button>
                        </div>
                    ) : (
                        <div className="hidden md:flex gap-3">
                            <Link to="/login" className="text-sm font-medium hover:text-primary transition-colors py-2">
                                Login
                            </Link>
                            <Link to="/signup" className="glass-button text-sm py-2 px-4 shadow-lg hover:shadow-primary/20">
                                Sign Up
                            </Link>
                        </div>
                    )}

                    <button
                        className="md:hidden text-gray-300 hover:text-white"
                        onClick={() => setIsOpen(!isOpen)}
                    >
                        {isOpen ? <X size={24} /> : <Menu size={24} />}
                    </button>
                </div>
            </div>

            {/* Mobile Menu */}
            {isOpen && (
                <div className="md:hidden glass-panel m-4 mt-0 p-4 flex flex-col gap-4 animate-fade-in">
                    <NavLink to="/deconstructor" icon={Search} label="Device Parser" />
                    <NavLink to="/scanner" icon={Scan} label="Note Scanner" />
                    <NavLink to="/quiz" icon={Award} label="Quiz" />

                    <div className="border-t border-glass-border pt-4 mt-2">
                        {user ? (
                            <div className="flex flex-col gap-3">
                                <div className="flex justify-between items-center text-gray-300">
                                    <span className="font-semibold">{user.name}</span>
                                    <span className="text-primary">{user.score} pts</span>
                                </div>
                                <button
                                    onClick={() => { logout(); setIsOpen(false); }}
                                    className="flex items-center gap-2 text-red-400 hover:text-red-300"
                                >
                                    <LogOut size={18} /> Logout
                                </button>
                            </div>
                        ) : (
                            <div className="flex flex-col gap-3">
                                <Link to="/login" onClick={() => setIsOpen(false)} className="w-full text-center py-2 rounded-lg bg-gray-800 hover:bg-gray-700">
                                    Login
                                </Link>
                                <Link to="/signup" onClick={() => setIsOpen(false)} className="glass-button justify-center w-full">
                                    Sign Up
                                </Link>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </nav>
    );
};

export default Navbar;
