import React from 'react';
import Navbar from './Navbar';
import { Heart } from 'lucide-react';

const Layout = ({ children }) => {
    return (
        <div className="min-h-screen flex flex-col pt-16">
            <Navbar />
            <main className="flex-grow container mx-auto px-4 py-8 animate-fade-in">
                {children}
            </main>
            <footer className="border-t border-glass-border mt-12 bg-black/20 backdrop-blur-sm">
                <div className="container mx-auto px-4 py-8">
                    <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
                        <div>
                            © {new Date().getFullYear()} E-Waste Awareness Hub. All rights reserved.
                        </div>
                        <div className="flex items-center gap-1">
                            Made with <Heart size={14} className="text-red-500 fill-current" /> for a greener future
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default Layout;
